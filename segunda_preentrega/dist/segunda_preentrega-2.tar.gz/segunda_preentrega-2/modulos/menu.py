import pre_entrega_uno 

pre_entrega_uno.start()