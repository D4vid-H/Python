from setuptools import setup

setup(
    name = "segunda_preentrega",
    version = '2',
    description= 'Paquete con la segunda pre entrega',
    author='David Hillton',

    packages=["modulos"]
)